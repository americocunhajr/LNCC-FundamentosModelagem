
ImgN = zeros(N/2, 1);
ImgS = zeros(N/2, N/2);
ImgD = zeros(N/2, N/2);

for m = 1:N/2
   Img1      = Image2Vector(VGImages{N/2+m});
   ImgN(m,1) = norm(Img1);
   
   for n = 1:N/2
      Img2      = Image2Vector(VGImages{n});
      ImgS(m,n) = Similarity(Img1,Img2);
      ImgD(m,n) = norm(Img1-Img2);
   end
   
   ImgS(m,:) = Normalize01(ImgS(m,:));
   ImgD(m,:) = Normalize01(ImgD(m,:));
end