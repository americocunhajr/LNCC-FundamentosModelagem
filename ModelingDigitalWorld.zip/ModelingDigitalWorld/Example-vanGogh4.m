
figure(1); imagesc(Normalize01(ImgN));
title('Brightness of Images'); 
c1 = colorbar; set(c1, 'FontSize', 24);
set(gca,'FontSize', 20,'XTickLabel', []);

figure(2); imagesc(ImgS); 
title('Similarity between images');
c2 = colorbar; set(c2, 'FontSize', 24);
set(gca,'FontSize', 20); 

figure(3); imagesc(ImgD); 
title('Distance between images');
c3 = colorbar; set(c3, 'FontSize', 24);
set(gca,'FontSize', 20); 