clc; clear; close all;

NameFiles = dir('*.jpg');
N         = length(NameFiles); 
VGImages  = cell(N, 1);

for n = 1:N
   CurrentFileName = NameFiles(n).name;
   CurrentImage    = imread(CurrentFileName);
   VGImages{n}     = CurrentImage;
end
  