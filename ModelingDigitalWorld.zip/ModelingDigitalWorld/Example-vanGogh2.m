
function v = Image2Vector(ImageRGB)
    v = reshape(double(ImageRGB/256),[],1);
end

function cos_theta = Similarity(v1,v2)
    cos_theta = dot(v1/norm(v1),v2/norm(v2));
end

function vn = Normalize01(v)
    vn = (v-min(v))/(max(v)-min(v));
end