clc; clear;

2+3
5-10
3^4
sqrt(3)
e
pi
sin(90)
cos(0)
tan(pi/4)
asin(1)
acos(-1)
atan(0)
