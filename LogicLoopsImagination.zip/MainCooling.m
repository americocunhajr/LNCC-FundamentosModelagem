clear; clc; close all

% Parameters
T0 = 35;           % initial temperature
steps = 20;        % number of time steps
alpha = 0.9;       % cooling factor (0 < alpha < 1)

% Preallocate and simulate
T = zeros(1, steps+1);
T(1) = T0;
for k = 1:steps
    T(k+1) = alpha * T(k);
end

% Plot the temperature evolution
figure;
plot(0:steps, T, 'o'); grid on;
xlabel('Step'); ylabel('Temperature');
title('Cooling process');