clc; clear;

a = [1; 2; 0]
b = [-1; 1; 0]
dot(a,b)
cross(a,b)