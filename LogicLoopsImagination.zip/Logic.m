clc; clear;

a = 5
b = 9

a == b
a ~= b
a < b
a <= b
a > b
a >= b
a > b && b ~= b
a > 0 || b ~= b
~(a>0)