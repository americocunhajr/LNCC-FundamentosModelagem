% function to solve a quadratic equationfunction [x1,x2] = eq2(a,b,c)  x1 = 0.5*(-b + sqrt(b^2-4*a*c));  x2 = 0.5*(-b - sqrt(b^2-4*a*c));
end