clc; clear;

A = [2 1; 1 3]
b = [4; 7]
x = A\b

A = [1 2; 2 4]
b = [3; 6]
x = A\b

A = [1 2; 2 4]
b = [3; 7]
x = A\b