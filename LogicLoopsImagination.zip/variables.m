% Numeric (scalar, vector, matrix)
x  = 3.14;                 % scalar
v  = [1, 2, 3, 4];         % row vector
M  = [1 2; 3 4];           % 2x2 matrix

% Logical
flagTrue  = true;          % logical true
flagFalse = false;         % logical false

% String / char
name1 = 'Americo';         % character array
