clc; clear;

x = exp(1)
y = log10(e)
z = log(e)
x + y
y-z
x*z
y/z
sqrt(-4)
sqrt(2)
format long
sqrt(2)