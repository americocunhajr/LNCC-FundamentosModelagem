% Test script for if-else
clc
clear

x = 2;
y = 3;

if x == y || x < 0
    disp('x is equal to y or x is negative');
else
    disp('x is not equal to y and x is not negative');
end
