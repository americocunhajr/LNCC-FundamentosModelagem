clc; clear;

A = [1 2 3 4; 4 3 2 1; 5 6 7 8; 8 7 6 5]
B = [2 0 0 0; 0 3 0 0; 0 0 4 0; 0 0 0 5]
A+B
A-B
A*B
A.*B
A'
det(A)

I = eye(3)
Z = zeros(3,4)
b = [1; 1; 1; 1]
C = A*b
C(3,1)