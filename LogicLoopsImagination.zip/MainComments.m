% Using comments to explain code and improve readability

% Compute the sum of the first N natural numbers
N = 10;             % you can change N
S = 0;              % accumulator

% Loop from 1 to N, adding to S
for k = 1:N
    S = S + k;
end

% Expected closed-form: N*(N+1)/2
S_closed = N*(N+1)/2;

% Show results
disp(['S (loop)     = ', num2str(S)]);
disp(['S (formula)  = ', num2str(S_closed)]);