% Test script for for loop
clc
clear

N = 4;
sumValue  = 0.0;
prodValue = 1.0;

for i = 1:N
    sumValue  = sumValue + i;
    prodValue = prodValue * (1 + i);
end
