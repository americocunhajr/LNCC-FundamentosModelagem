% Ask for a number and print its square
x = input('Enter a number: ');
y = x^2;

disp(['The square is: ', num2str(y)]);

% Ask for a name
name = input('Enter your name: ', 's');
disp(['Hello, ' name '!']);
