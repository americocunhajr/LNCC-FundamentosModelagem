% Test script for while loop
clc
clear

k = 1;
N = 3;
x = 0.0;

while k <= N && x < 30.0
    x = x + sqrt(k);
    k = k + 1;
end
