clear; clc; close all

% Parameters
r = 1.2;        % intrinsic growth rate
K = 100;        % carrying capacity
x0 = 5;         % initial population

% Define ODE and temporal domain
f.    = @(t,x) r*x*(1 - x/K);
tspan = [0 10];

% Integrate the ODE model
[t,x] = ode45(f, tspan, x0);

% Plot population evolution
plot(t, x, 'LineWidth', 2); grid on;
xlabel('t'); ylabel('x(t)')'
title('Logistic growth')